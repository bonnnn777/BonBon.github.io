function hello() {
  alert("Hello how are you doing?");
}

function showtime() {
  var now = new Date();
  alert(now);
}
